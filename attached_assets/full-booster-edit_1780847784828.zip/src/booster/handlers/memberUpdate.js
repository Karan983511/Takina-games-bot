import { handleBoostLost, restoreRole } from '../services/roleService.js';
import { getSettings, isEnabled } from '../services/settingsService.js';
import { audit, log } from '../utils/logger.js';
import BoosterRole from '../models/BoosterRole.js';

export async function handleBoostChange(oldMember, newMember, client) {
  // No change in boost status
  if (!!oldMember.premiumSince === !!newMember.premiumSince) return;

  const { guild, id: userId } = newMember;
  const settings = await getSettings(guild.id);

  // ── Boost LOST ────────────────────────────────────────────────────────────
  if (oldMember.premiumSince && !newMember.premiumSince) {
    log('info', 'MemberUpdate', `${userId} lost boost in ${guild.id}`);

    if (isEnabled(settings, 'customRoles')) {
      await handleBoostLost(guild, userId).catch(err =>
        log('error', 'MemberUpdate', `handleBoostLost failed for ${userId}: ${err.message}`)
      );
    }

    await audit(client, guild.id, userId, 'BOOST_LOST', {});

    const ch = settings.logChannelId ? guild.channels.cache.get(settings.logChannelId) : null;
    ch?.send({
      content: `💔 <@${userId}> stopped boosting — custom role removed. Data preserved for **${settings.retention?.days ?? 7} days**.`,
    }).catch(() => {});
  }

  // ── Boost GAINED / RESTORED ───────────────────────────────────────────────
  if (!oldMember.premiumSince && newMember.premiumSince) {
    log('info', 'MemberUpdate', `${userId} gained boost in ${guild.id}`);

    let restored = null;
    if (isEnabled(settings, 'customRoles')) {
      restored = await restoreRole(guild, userId).catch(err => {
        log('error', 'MemberUpdate', `restoreRole failed for ${userId}: ${err.message}`);
        return null;
      });
    }

    await audit(client, guild.id, userId, 'BOOST_GAINED', { roleRestored: !!restored });

    const ch = settings.logChannelId ? guild.channels.cache.get(settings.logChannelId) : null;
    ch?.send({
      content: `💎 <@${userId}> is boosting again! ${restored ? '✅ Custom role automatically restored.' : 'No previous role found — use `.role setup` to create one.'}`,
    }).catch(() => {});
  }
}

/**
 * Called when any member leaves the server.
 * If they had a booster role, delete it from Discord but preserve the DB record.
 */
export async function handleMemberLeave(member) {
  const { guild, id: userId } = member;

  try {
    const doc = await BoosterRole.findOne({ guildId: guild.id, userId });
    if (!doc) return;

    log('info', 'MemberUpdate', `Member ${userId} left — preserving role data`);

    if (doc.active) {
      // Active role: delete from Discord, preserve DB
      await handleBoostLost(guild, userId).catch(() => {});
      // Update leftGuildAt after handleBoostLost ran
      await BoosterRole.updateOne(
        { guildId: guild.id, userId },
        { $set: { leftGuildAt: new Date() } },
      );
    } else {
      // Already inactive: just stamp leftGuildAt
      doc.leftGuildAt = new Date();
      await doc.save();
    }
  } catch (err) {
    log('error', 'MemberUpdate', `handleMemberLeave error for ${userId}: ${err.message}`);
  }
}
