import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';

const PAGES = {
  main: () => new EmbedBuilder().setColor(0xF47FFF)
    .setTitle('🌸 Takina Booster Bot — Help Menu')
    .setDescription('Use the buttons below to browse help sections, or type `.help <section>`.')
    .addFields(
      { name: '🎨 Booster Commands', value: '`.help booster` — Custom roles, VCs, templates, backups', inline: true },
      { name: '⚙️ Settings',         value: '`.help settings` — Admin panel, boundaries, toggles',    inline: true },
      { name: '🗳️ Voting',           value: '`.help vote` — Featured role voting system',              inline: true },
      { name: '🏆 Hall of Fame',     value: '`.help hof` — Leaderboard & featured history',           inline: true },
    )
    .setFooter({ text: 'Prefix: .  |  Only boosters can use booster commands.' }),

  booster: () => new EmbedBuilder().setColor(0xF47FFF).setTitle('🎨 Booster Commands')
    .addFields(
      { name: '`.booster`',                    value: 'Open your personal dashboard' },
      { name: '`.booster request-role`',       value: 'Request a custom role (opens a form)' },
      { name: '`.booster request-vc`',         value: 'Request a custom voice channel' },
      { name: '`.booster edit name <name>`',   value: 'Rename your custom role' },
      { name: '`.booster edit color <#hex>`',  value: 'Change your role color (e.g. `#FF6B35`)' },
      { name: '`.booster share add @user`',    value: 'Let another member wear your role' },
      { name: '`.booster share remove @user`', value: 'Remove a member from your role' },
      { name: '`.booster share list`',         value: 'Show who has access to your role' },
      { name: '`.booster template list`',      value: 'Browse available color templates' },
      { name: '`.booster template apply <name>`', value: 'Apply a template to your role' },
      { name: '`.booster backup`',             value: 'Save a backup of your role and VC' },
      { name: '`.booster restore`',            value: 'Restore your role and VC from backup' },
      { name: '`.booster vote`',               value: 'Vote for a booster role to be featured' },
      { name: '`.booster vote status`',        value: 'See the current vote standings' },
      { name: '`.booster hof`',               value: 'View the Hall of Fame' },
      { name: '`.booster role delete`',       value: 'Soft-delete your custom role (data kept)' },
      { name: '`.booster vc delete`',         value: 'Delete your custom VC' },
    ),

  settings: () => new EmbedBuilder().setColor(0x5865F2).setTitle('⚙️ Settings Commands')
    .setDescription('Admin only — requires Manage Guild permission.')
    .addFields(
      { name: '`.settings panel`',                         value: 'Open the full settings dashboard' },
      { name: '`.settings toggle <feature>`',              value: 'Enable or disable a feature' },
      { name: '`.settings boundaries`',                    value: 'View current role boundaries' },
      { name: '`.settings boundaries set @upper @lower`',  value: 'Set upper and lower role boundaries' },
      { name: '`.settings templates list`',                value: 'List all templates' },
      { name: '`.settings templates add <name> <#color>`', value: 'Add a custom template' },
      { name: '`.settings templates remove <name>`',       value: 'Remove a custom template' },
      { name: '`.settings history`',                       value: 'View the audit log' },
      { name: '`.settings vote start [days]`',             value: 'Start a vote session' },
      { name: '`.settings vote end`',                      value: 'End the current vote session early' },
      { name: '`.settings rotation set <days>`',           value: 'Set the rotation interval in days' },
      { name: '`.settings log #channel`',                  value: 'Set a channel for bot action logs' },
    ),

  vote: () => new EmbedBuilder().setColor(0xFEE75C).setTitle('🗳️ Voting System')
    .setDescription('Members vote for which booster role gets featured each week.')
    .addFields(
      { name: 'How it works', value: '1. Admin starts a session\n2. Members vote for their favourite role\n3. Most-voted role becomes featured' },
      { name: '`.booster vote`',        value: 'Cast or change your vote' },
      { name: '`.booster vote status`', value: 'See current standings' },
      { name: '`.settings vote start`', value: 'Admin: start a new vote session' },
      { name: '`.settings vote end`',   value: 'Admin: end the session early' },
    ),

  hof: () => new EmbedBuilder().setColor(0xFFD700).setTitle('🏆 Hall of Fame')
    .setDescription('A permanent record of every featured booster role.')
    .addFields(
      { name: '`.booster hof`', value: 'View the featured role leaderboard' },
      { name: 'Tracks',         value: '• Featured roles\n• Total votes\n• Auto-rotation vs vote wins' },
    ),
};

function pageButtons(current) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('booster_help_main').setLabel('Home').setStyle(current === 'main' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('booster_help_booster').setLabel('Booster').setStyle(current === 'booster' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('booster_help_settings').setLabel('Settings').setStyle(current === 'settings' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('booster_help_vote').setLabel('Voting').setStyle(current === 'vote' ? ButtonStyle.Primary : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('booster_help_hof').setLabel('Hall of Fame').setStyle(current === 'hof' ? ButtonStyle.Primary : ButtonStyle.Secondary),
  );
}

export async function execute(message, args) {
  const section = (args[0] ?? 'main').toLowerCase();
  const page    = PAGES[section] ?? PAGES.main;
  return message.channel.send({ embeds: [page()], components: [pageButtons(section)] });
}

export function getPage(section) {
  return { embed: (PAGES[section] ?? PAGES.main)(), row: pageButtons(section) };
}
