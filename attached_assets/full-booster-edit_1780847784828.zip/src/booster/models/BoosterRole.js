import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  guildId:        { type: String, required: true },
  userId:         { type: String, required: true },
  roleId:         { type: String, default: null },   // null when Discord role is deleted
  name:           { type: String, required: true },
  color:          { type: String, default: '#99AAB5' },
  colorSecondary: { type: String, default: null },
  iconType:       { type: String, enum: ['none', 'emoji', 'custom', 'image'], default: 'none' },
  icon:           { type: String, default: null },
  template:       { type: String, default: null },
  sharedWith:     { type: [String], default: [] },
  active:         { type: Boolean, default: true },
  softDeletedAt:  { type: Date, default: null },     // set when boost is lost
  leftGuildAt:    { type: Date, default: null },     // set when member leaves server
}, { timestamps: true });

schema.index({ guildId: 1, userId: 1 });
schema.index({ guildId: 1, roleId: 1 });
schema.index({ guildId: 1, active: 1, softDeletedAt: 1 });

export default mongoose.model('BoosterRole', schema);
