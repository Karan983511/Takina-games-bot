import BoosterRole from '../models/BoosterRole.js';
import { getInsertPosition, assertBoundary } from '../utils/boundary.js';
import { log } from '../utils/logger.js';

export async function createBoosterRole(guild, userId, { name, color, icon, template }) {
  const position  = await getInsertPosition(guild);
  const roleData  = { name, color: color || '#99AAB5', hoist: false, mentionable: false };
  if (icon) roleData.icon = icon;

  const discordRole = await guild.roles.create(roleData);
  await discordRole.setPosition(position).catch(() => {});
  log('info', 'RoleService', `Created role ${discordRole.id} (${name}) for ${userId}`);

  const doc = await BoosterRole.findOneAndUpdate(
    { guildId: guild.id, userId },
    {
      $set: {
        roleId:        discordRole.id,
        name,
        color:         color || '#99AAB5',
        icon:          icon  || null,
        template:      template || null,
        active:        true,
        softDeletedAt: null,
        leftGuildAt:   null,
      },
    },
    { upsert: true, new: true },
  );

  const member = guild.members.cache.get(userId)
               ?? await guild.members.fetch(userId).catch(() => null);
  if (member) await member.roles.add(discordRole).catch(() => {});

  return { doc, discordRole };
}

export async function editBoosterRole(guild, userId, updates) {
  const doc = await BoosterRole.findOne({ guildId: guild.id, userId, active: true });
  if (!doc) throw new Error('No active booster role found.');

  const discordRole = guild.roles.cache.get(doc.roleId);
  if (!discordRole) throw new Error('Discord role no longer exists. Try restoring.');

  await assertBoundary(guild, discordRole);

  const patch = {};
  if (updates.name  !== undefined) { patch.name  = updates.name;  doc.name  = updates.name;  }
  if (updates.color !== undefined) { patch.color = updates.color; doc.color = updates.color; }
  if (updates.icon  !== undefined) { patch.icon  = updates.icon;  doc.icon  = updates.icon;  }

  await discordRole.edit(patch);
  await doc.save();
  return { doc, discordRole };
}

/**
 * Called when a member LOSES boost.
 * Deletes the Discord role from the server entirely.
 * Preserves the DB record (name, color, icon, sharedWith) for auto-restoration later.
 */
export async function handleBoostLost(guild, userId) {
  const doc = await BoosterRole.findOne({ guildId: guild.id, userId, active: true });
  if (!doc) return null;

  // Remove from every member who has the role
  const discordRole = guild.roles.cache.get(doc.roleId);
  if (discordRole) {
    for (const memberId of [...doc.sharedWith, userId]) {
      const m = guild.members.cache.get(memberId)
             ?? await guild.members.fetch(memberId).catch(() => null);
      if (m) await m.roles.remove(discordRole).catch(() => {});
    }
    await discordRole.delete('Booster lost boost').catch(() => {});
  }

  // Preserve record — null out roleId since Discord role is gone
  doc.active        = false;
  doc.softDeletedAt = new Date();
  doc.roleId        = null;
  await doc.save();

  log('info', 'RoleService', `Boost lost — deleted Discord role for ${userId}, DB data preserved`);
  return doc;
}

// Legacy alias kept for compatibility
export const softDeleteRole = handleBoostLost;

/**
 * Called when a member REGAINS boost.
 * Recreates the Discord role from preserved DB data and reassigns it.
 */
export async function restoreRole(guild, userId) {
  const doc = await BoosterRole.findOne({ guildId: guild.id, userId, active: false });
  if (!doc) return null;

  const position  = await getInsertPosition(guild);
  const roleData  = { name: doc.name, color: doc.color, hoist: false, mentionable: false };
  if (doc.icon) roleData.icon = doc.icon;

  const discordRole = await guild.roles.create(roleData).catch(() => null);
  if (!discordRole) return null;
  await discordRole.setPosition(position).catch(() => {});

  doc.roleId        = discordRole.id;
  doc.active        = true;
  doc.softDeletedAt = null;
  doc.leftGuildAt   = null;
  await doc.save();

  // Restore to owner
  const owner = guild.members.cache.get(userId)
              ?? await guild.members.fetch(userId).catch(() => null);
  if (owner) await owner.roles.add(discordRole).catch(() => {});

  // Restore to shared members still in server
  for (const sharedId of doc.sharedWith) {
    const sm = guild.members.cache.get(sharedId)
             ?? await guild.members.fetch(sharedId).catch(() => null);
    if (sm) await sm.roles.add(discordRole).catch(() => {});
  }

  log('info', 'RoleService', `Restored role for ${userId} → ${discordRole.id}`);
  return { doc, discordRole };
}

/**
 * Hard-deletes a role — used by .role delete command (manual deletion by owner).
 */
export async function deleteBoosterRole(guild, userId) {
  const doc = await BoosterRole.findOne({ guildId: guild.id, userId });
  if (!doc) return null;

  if (doc.roleId) {
    const dr = guild.roles.cache.get(doc.roleId);
    if (dr) {
      for (const memberId of [...doc.sharedWith, userId]) {
        const m = guild.members.cache.get(memberId)
               ?? await guild.members.fetch(memberId).catch(() => null);
        if (m) await m.roles.remove(dr).catch(() => {});
      }
      await dr.delete('Deleted by owner').catch(() => {});
    }
  }

  await BoosterRole.deleteOne({ _id: doc._id });
  log('info', 'RoleService', `Hard-deleted role record for ${userId}`);
  return doc;
}
